package com.java.ds.array.template;

public class ZigZagArray
{
    public static void main ( String[] args )
    {
        
    }
}
