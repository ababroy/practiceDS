package com.java.ds.array.template;

import java.util.Arrays;

public class FibonacciSeries
{
    public static void main ( String[] args )
    {
        int n = 6;
        

    }
}
