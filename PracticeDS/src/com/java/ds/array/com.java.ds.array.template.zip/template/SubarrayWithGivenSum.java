package com.java.ds.array.template;

public class SubarrayWithGivenSum
{
    static int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};//{ 1, 2, 3, 7, 5 };

    static int targetVal = 151; //12;

    public static void main ( String[] args )
    {
        
    }

}
