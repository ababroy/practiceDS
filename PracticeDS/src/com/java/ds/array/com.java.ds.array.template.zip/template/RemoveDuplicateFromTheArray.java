package com.java.ds.array.template;

public class RemoveDuplicateFromTheArray
{
    static int arr[] = {1,1,1,1,1,2,2,2,2,3,3,4,5}; //{ 1, 1, 2 }; // {1,1,1,2,2,2,3,3,4};

    public static void main ( String[] args )
    {
        
    }
}
