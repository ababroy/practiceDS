package com.java.ds.array.template;

public class DutchNationalFlagProblem
{
    static int arr[] = { 0, 1, 1, 0, 1, 2, 1, 2, 0, 0, 0, 1 };

    public static void main ( String[] args )
    {
        
    }
}
