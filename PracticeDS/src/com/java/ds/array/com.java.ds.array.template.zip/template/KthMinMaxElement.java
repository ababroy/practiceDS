package com.java.ds.array.template;

import java.util.Arrays;

public class KthMinMaxElement
{
    public static void main ( String[] args )
    {
        int[] arr = { 5, 8, 12, 7, 6, 2, 4 }; 
        int kTh = 5;

        kThSmallestElement( arr, kTh ); // 2,4,5,6,[7],8,12
        kThLargestElement( arr, kTh ); // 12,8,7,6,[5],4,2
    }

    private static void kThLargestElement ( int[] arr, int kTh )
    {
        
    }

    private static void kThSmallestElement ( int[] arr, int kTh )
    {
        
    }

}
