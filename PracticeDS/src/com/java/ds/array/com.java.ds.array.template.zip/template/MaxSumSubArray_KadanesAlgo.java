package com.java.ds.array.template;

public class MaxSumSubArray_KadanesAlgo
{
    public static void main ( String[] args )
    {
        int[] arr = { 4, -3, -2, 2, 3, 1, -2, -3, 4, 2, -6, -3, -1, 3, 1, 2 };
        
    }
    
}
