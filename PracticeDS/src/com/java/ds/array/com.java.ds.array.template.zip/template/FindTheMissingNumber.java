package com.java.ds.array.template;

public class FindTheMissingNumber
{
    public static void main ( String[] args )
    {
        int[] arr = { 1, 2, 3, 4, 5, 6, 8 };

        usingSumFormula( arr );
        usingXorFormula( arr );

    }

    private static void usingXorFormula ( int[] arr )
    {
        
    }

    private static void usingSumFormula ( int[] arr )
    {
        
    }
}
