package com.java.ds.array.template;

public class SortTwoArraysWithoutExtraSpace
{
    public static void main ( String[] args )
    {
        int arr1[] = { 1, 3, 5, 7, 9 }; // 1,2,3,4,5
        int arr2[] = { 2, 4, 8, 10, 11, 12, 16 }; // 7,8,9,10,11,12,16
        
    }
}
