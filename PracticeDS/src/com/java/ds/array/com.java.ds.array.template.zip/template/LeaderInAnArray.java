package com.java.ds.array.template;

public class LeaderInAnArray
{
    static int arr[] = { 15, 16, 3, 2, 6, 1, 4 };

    public static void main ( String[] args )
    {
        simpleMethod( arr );       // O(n^2)
        maxFromRightMethod( arr ); // O(n)
    }

    private static void maxFromRightMethod ( int[] arr )
    {
        
    }

    private static void simpleMethod ( int[] arr )
    {
        
    }
}
