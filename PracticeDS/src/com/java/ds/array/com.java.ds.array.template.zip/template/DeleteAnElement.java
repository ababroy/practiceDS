package com.java.ds.array.template;

import java.util.Arrays;

public class DeleteAnElement
{
    public static void main ( String[] args )
    {
        int[] arr = {10,40,30,80,60,20};
        int tbd = 30;
        
        
        
        System.out.println( Arrays.toString(arr) );
    }
}
