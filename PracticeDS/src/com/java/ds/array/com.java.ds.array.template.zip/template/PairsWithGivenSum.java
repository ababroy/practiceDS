package com.java.ds.array.template;

import java.util.Arrays;

public class PairsWithGivenSum
{
    public static void main ( String[] args )
    {
        int[] arr = { 5, 8, 3, 4, 2, 6, 10, 7, 1, 9 };
        int givenSum = 11;

        
    }
}
