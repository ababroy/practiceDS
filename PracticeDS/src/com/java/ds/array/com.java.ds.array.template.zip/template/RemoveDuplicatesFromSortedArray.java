package com.java.ds.array.template;

public class RemoveDuplicatesFromSortedArray
{
//    static int arr[] = { 1, 2, 2, 3, 3, 3, 4, 4 };

     static int arr[] = { 1, 2, 2, 3, 3, 4, 4, 4, 5 };

    public static void main ( String[] args )
    {
        // usingExtraSpace(arr);
        usingConstantSpace( arr );
    }

    private static void usingConstantSpace ( int arr[] )
    {
        
    }

    private static void usingExtraSpace ( int arr[] )
    {
        
    }

}
