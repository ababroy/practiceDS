package com.java.ds.array.template;

/**
 * 1. Make two parts of the array as (n-r) and r
 * 
 * 2. Reverse part1 and part2 = Part1reverse Part2reverse
 * 
 * 3. Reverse whole Part1reverse.Part2reverse
 * 
 * @author AROY
 *
 */
public class RotationOfAnArray
{
    static int arr[] = { 1, 2, 3, 4, 5, 6, 7 }; // {5,4,3,2,1,7,6} // {6,7,1,2,3,4,5}

    static int rotate = 2;

    public static void main ( String[] args )
    {
        
    }

}
